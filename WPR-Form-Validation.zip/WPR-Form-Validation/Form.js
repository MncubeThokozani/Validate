//The Validation of the name and surname

const Name = document.getElementById("Name");
const Surname = document.getElementById("Surname");
const form = document.getElementById("form");
const Phone = document.getElementById("PhoneNumber");
const NameError = document.getElementById("FirstName");
const SurnameError = document.getElementById("Last");
const PhoneNumberError = document.getElementById("Cell");



// The ticks
const TickName = document.getElementById("TickName");
const TickLastName = document.getElementById("TickLastName");
const phoneNumberTick = document.getElementById("TickNumber");
const RefTick =document.getElementById("TickRef")
const UserIDTick = document.getElementById("TickID")


form.addEventListener("submit", (e) => {
  e.preventDefault(); // Prevent form submission

  // Validation function to check if the input contains only letters
  function isValidNameOrSurname(input) {
    return /^[A-Za-z]+$/.test(input);
  }

  // Check Name input
  if (isValidNameOrSurname(Name.value)) {
    TickName.style.color = "Green";
  } else {
    NameError.style.color = "Red";
    TickName.style.color = "Red";
  }

  // Check Surname input
  if (isValidNameOrSurname(Surname.value)) {
    TickLastName.style.color = "Green";
  } else {
    SurnameError.style.color = "Red";
    TickLastName.style.color = "Red";
  }

  //validate email.
function validateemail()  
{  
const Email = document.getElementById("Email");
var atsign=x.indexOf("@");  
var fullstop=Email.lastIndexOf(".");  
const EmailTick = document.getElementById("TickEmail");
const EmailError = document.getElementById("Mail");
if (atsign<1 || fullstop<atsign+2 || fullstop+2>=Email.length){  
  alert("Please enter a valid e-mail address with the correct format: \n(make use of \" @ or . \")");  
  EmailError.style.color = "Red";
  EmailTick.style.color = "Red";
  return false;  
  }  
  else {
    EmailTick.style.color = "Red";
  }
} 
function displaySummary() {
  summaryDiv.innerHTML = `
    <h2>Summary</h2>
    <p>Name: ${Name.value}</p>
    <p>Surname: ${Surname.value}</p>
    <p>Email: ${Email.value}</p>
    <p>Phone Number: ${Phone.value}</p>
    <p>Country: ${countryDropdown.value}</p>
    <p>State: ${stateDropdown.value}</p>
    <p>City: ${cityDropdown.value}</p>
  `;
  form.style.display = "none"; // Hide the form
  summaryDiv.style.display = "block"; // Display the summary
}

RefTick.style.color = "Green";
UserIDTick.style.color = "Green"
});


//Dropdown (Country, state and city) validation
    const countryDropdown = document.getElementById('Countries');
    const stateDropdown = document.getElementById('State');
    const cityDropdown = document.getElementById('City');

    const stateOptions = {
      UnitedStates: ['California', 'New York', 'Texas'],
      SouthAfrica: ['Gauteng', 'Limpopo', 'Mpumalanga'],
      India: ['Bihar', 'Maharashtra', 'Goa']
    };

    const cityOptions = {
      California: ['Los Angeles', 'San Francisco', 'San Diego'],
      'New York': ['New York City', 'Buffalo', 'Rochester'],
      Texas: ['Houston', 'Dallas', 'Austin'],
      Gauteng: ['Johannesburg', 'Pretoria', 'Centurion'],
      Limpopo: ['Polokwane', 'Mokopane', 'Haenertsburg'],
      Mpumalanga: ['Barberton', 'Mbombela', 'Lydenburg'],
      Bihar: ['Purnia', 'Buxar', 'Bhagalpur'],
      Maharashtra: ['Pune', 'Mumbai', 'Nagpur'],
      Goa: ['Canacona', 'Panaji', 'Mapusa']
    };

    function updateStates() {
      const selectedCountry = countryDropdown.value;
      stateDropdown.innerHTML = '<option value="invalid">Select a state</option>';
      cityDropdown.innerHTML = '<option value="invalid">Select a city</option>';

      if (selectedCountry !== 'invalid') {
        stateDropdown.disabled = false;
        stateOptions[selectedCountry].forEach(state => {
          const option = document.createElement('option');
          option.value = state;
          option.textContent = state;
          stateDropdown.appendChild(option);
        });
      } else {
        stateDropdown.disabled = true;
        cityDropdown.disabled = true;
      }
    }

    function updateCities() {
      const selectedState = stateDropdown.value;
      cityDropdown.innerHTML = '<option value="invalid">Select a city</option>';

      if (selectedState !== 'invalid') {
        cityDropdown.disabled = false;
        cityOptions[selectedState].forEach(city => {
          const option = document.createElement('option');
          option.value = city;
          option.textContent = city;
          cityDropdown.appendChild(option);
        });
      } else {
        cityDropdown.disabled = true;
      }
    }
//Phone number valdiations 

form.addEventListener("submit", (e) => {
  e.preventDefault(); // Prevent form submission

  // Validation function to check if the input contains only letters
  function isValidNumber(input) {
    return /^[0-9]+$/.test(input);
  }

  // Check Number
  if (isValidNumber(Phone.value)) {
    phoneNumberTick.style.color = "Green";
  } else {
    PhoneNumberError.style.color = "Red";
    phoneNumberTick.style.color = "Red";
  }
});

//Validation for dropdowns 
function validateForm() {
  var country = document.getElementById("Countries").value;
  var state = document.getElementById("State").value;
  var city = document.getElementById("City").value;

  if (country === "invalid") {
      alert("Please select a country.");
      return false;
  }

  if (state === "invalid") {
      alert("Please select a state.");
      return false;
  }

  if (city === "invalid") {
      alert("Please select a city.");
      return false;
  }

  return true;
}
