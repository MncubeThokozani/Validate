
const Name=document.getElementById("Name");
const Email=document.getElementById("Email");
const countries=document.getElementById("Countries");
const PhoneNumber=document.getElementById("Phone Number");
const Surname=document.getElementById("Surname");
const UserID=document.getElementById("User-ID");
const State=document.getElementById("State");
const City=document.getElementById("City");
const Reference=document.getElementById("Reference");

const Nameid = document.getElementById("Nameid");
const Surnameid=get.document.getElementById("Surnameid");
const Emailid=document.getElementById("Emailid");
const PhoneNumberid=document.getElementById("Phone Numberid");
const Countryid=document.getElementById("Countryid");
const Stateid=document.getElementById("Stateid");
const Cityid=document.getElementById("Cityid");
const Userid=document.getElementById("Userid");
const Referenceid=document.getElementById("Referenceid");

Nameid.innerHTML="Name: "+Name.value;
Surnameid.innerHTML="Surname: "+ Surname.value;
Emailid.innerHTML="Email: "+ Email;
PhoneNumberid.innerHTML="Phone Number: "+ PhoneNumber.value;
Countryid.innerHTML="Country: "+ countries.value;
Stateid.innerHTML="State: "+ State.value;
Cityid.innerHTML="City: "+City.value;
Userid.innerHTML="UserID"+UserID.value;
Referenceid.innerHTML="Reference"+Reference.value;


   
   